create
    definer = root@localhost procedure ReadOeuvres()
BEGIN

    DECLARE id integer;
    DECLARE titre varchar(100);
    DECLARE prix integer;
    DECLARE hautDeGamme BIT(1) default FALSE;
    DECLARE lecture_complete BIT(1) DEFAULT 0;
    DECLARE curseur CURSOR FOR SELECT O.id,O.titre,O.prix FROM oeuvres O;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET lecture_complete = 1;

    CREATE TABLE IF NOT EXISTS SpecialPrices (id integer,titre varchar(100),prix integer,hautDeGamme BIT(1));

    OPEN curseur;
    lecteur: LOOP
        FETCH curseur INTO id,titre,prix;
        IF lecture_complete=1 THEN
            leave lecteur;
        end if;


        IF hautDeGamme = 1 THEN
            INSERT INTO SpecialPrices VALUES(id,titre,prix*1.5,1);
        ELSE
                INSERT INTO SpecialPrices VALUES(id,titre,prix*1.5,0);
        end if;

    END loop lecteur;

    CLOSE curseur;
END;

