create
    definer = root@localhost procedure UpdatePrice(IN factor float)
BEGIN
    UPDATE oeuvres O SET  O.prix = O.prix * factor;
end;

